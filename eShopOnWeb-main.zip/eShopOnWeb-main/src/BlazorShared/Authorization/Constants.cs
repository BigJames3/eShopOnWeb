﻿namespace BlazorShared.Authorization;

public static class Constants
{
    public static class Roles
    {
        public const string ADMINISTRATORS = "Administrators";
    }
}
